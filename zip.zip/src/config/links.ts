export const COMMUNITY_LINKS = {
  instagram: 'https://www.instagram.com/foundersbatch?obrf=MWdkMW55MWNrdWtwYw==',
  telegram: 'https://t.me/+UDQnBLLFVn40ZmQ1',
  whatsapp: 'https://chat.whatsapp.com/CvU3domcthBEp6JFHI8KbA?s=cl&p=a&mlu=4&ilr=4&iam=2',
  discord: 'https://discord.gg/founderbatch',
  linkedin: 'https://linkedin.com/company/founderbatch',
  twitter: 'https://x.com/founderbatch',
} as const;
