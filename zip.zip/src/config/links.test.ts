import test from 'node:test';
import assert from 'node:assert/strict';
import { COMMUNITY_LINKS } from './links';

test('Instagram link matches user specified URL with tracking parameter', () => {
  assert.equal(
    COMMUNITY_LINKS.instagram,
    'https://www.instagram.com/foundersbatch?obrf=MWdkMW55MWNrdWtwYw=='
  );
  const parsed = new URL(COMMUNITY_LINKS.instagram);
  assert.equal(parsed.hostname, 'www.instagram.com');
  assert.equal(parsed.pathname, '/foundersbatch');
  assert.equal(parsed.searchParams.get('obrf'), 'MWdkMW55MWNrdWtwYw==');
});

test('Telegram link matches user specified invite link', () => {
  assert.equal(COMMUNITY_LINKS.telegram, 'https://t.me/+UDQnBLLFVn40ZmQ1');
  const parsed = new URL(COMMUNITY_LINKS.telegram);
  assert.equal(parsed.hostname, 't.me');
  assert.equal(parsed.pathname, '/+UDQnBLLFVn40ZmQ1');
});

test('WhatsApp link matches user specified invite group URL with all query parameters', () => {
  assert.equal(
    COMMUNITY_LINKS.whatsapp,
    'https://chat.whatsapp.com/CvU3domcthBEp6JFHI8KbA?s=cl&p=a&mlu=4&ilr=4&iam=2'
  );
  const parsed = new URL(COMMUNITY_LINKS.whatsapp);
  assert.equal(parsed.hostname, 'chat.whatsapp.com');
  assert.equal(parsed.pathname, '/CvU3domcthBEp6JFHI8KbA');
  assert.equal(parsed.searchParams.get('s'), 'cl');
  assert.equal(parsed.searchParams.get('p'), 'a');
  assert.equal(parsed.searchParams.get('mlu'), '4');
  assert.equal(parsed.searchParams.get('ilr'), '4');
  assert.equal(parsed.searchParams.get('iam'), '2');
});
